﻿using SampleMVCApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;

namespace SampleMVCApp.Controllers
{
    public class FirstExampleController : Controller
    {
        public string HelloWorld() => "Hai From MVC"; 

        public double GetNumber(string v1,string v2)
        {
            double first = double.Parse(v1);
            double second = double.Parse(v2);
            return first + second;

        } 
        public ViewResult Displayemployee()
        {
            Employee employee = new Employee
            {
                EmployeeId=1,
                EmployeeName="Dharani",
                EmployeeEmail="dharani@gmail.com",
                EmployeeSalary=35000
            };
            return View(employee);
        }
    }
}