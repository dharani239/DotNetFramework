﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1
{
   
    public class ProductComponentEntity
    {
        static List<tblProduct> _proc = new List<tblProduct>();
        static ProductComponentEntity()
        {
            //getAllProducts();
        }
        public static List<tblProduct> AllProducts => _proc;
        private static void getAllProducts()
        {
            throw new NotImplementedException();
        }

        public static void AddNewProduct(tblProduct product)
        {
            var context = new ProductEntities();
            context.tblProducts.Add(product);
            context.SaveChanges();
        }
        public static void UpdateProduct(tblProduct product)
        {
            var context = new ProductEntities();
            var foundprod = (from prod in context.tblProducts
                            where prod.ProductId == product.ProductId
                            select prod).FirstOrDefault();
            if (foundprod == null)
            {
                throw new Exception("Employee not found!!!");
            }
            //set the new values
            foundprod.ProductName = product.ProductName;
            foundprod.Price = product.Price;
            foundprod.Quantity = product.Quantity;
            foundprod.Image = product.Image;
            //save changes
            context.SaveChanges();


        }
        public static void DeleteProduct(int id)
        {
            var context = new ProductEntities();
            var foundprod = context.tblProducts.FirstOrDefault((p) => p.ProductId == id);
            if (foundprod == null) throw new Exception("Product not found to Delete");
            context.tblProducts.Remove(foundprod);
            context.SaveChanges();
        }
    }
       
}
    
