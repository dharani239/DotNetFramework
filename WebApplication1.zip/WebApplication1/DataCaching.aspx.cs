﻿using DataAccessLib;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Caching;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class DataCaching : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                cacheObject();
                grdDetails.DataSource = Cache["myData"] as List<Product>;
                grdDetails.DataBind();
            }
            


        }
        private void cacheObject()
        {
            if (Cache["myData"] == null)
            {
                var component = ProductFactory.GetComponent();
                var data = component.GetAllProducts();
                var textFile = Server.MapPath("MyCache.txt");
                //Cache.Add("myData", data, new System.Web.Caching.CacheDependency(textFile), DateTime.Now.AddMinutes(5), System.Web.Caching.Cache.NoSlidingExpiration, System.Web.Caching.CacheItemPriority.Default, null);
                string strCon = ConfigurationManager.ConnectionStrings["cacheString"].ConnectionString;
                SqlCacheDependencyAdmin.EnableNotifications(strCon);
                SqlCacheDependencyAdmin.EnableTableForNotifications(strCon, "tblProduct");
                SqlCacheDependency dep = new SqlCacheDependency("Output-cache", "tblProduct");
                Cache.Add("myData", data, dep, DateTime.Now.AddMinutes(5), Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
                Response.Write("Data got from the Database");
            }
            else
            {
                Response.Write("Data got from the Cache");
            }
        }
    }
}