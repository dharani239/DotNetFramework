﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLib
{
    public interface IProductDB
    {
        void AddProduct(tblProduct product);
        void UpdateProduct(tblProduct product);
        void DeleteProduct(int id);
        List<tblProduct> GetAllProducts();
    }

    public static class ProductFactory
    {
        public static IProductDB GetComponent() => new ProductDB();
    }
    class ProductDB : IProductDB
    {
        static MyDbEntities context = new MyDbEntities();
        public void AddProduct(tblProduct product)
        {
            context.tblProducts.Add(product);
            context.SaveChanges();
        }
        public void DeleteProduct(int id)
        {
            var found = context.tblProducts.First((p) => p.ProductId == id);
            context.tblProducts.Remove(found);
            context.SaveChanges();
        }

        public List<tblProduct> GetAllProducts() => context.tblProducts.ToList();

        public void UpdateProduct(tblProduct product)
        {
            var found = context.tblProducts.First((p) => p.ProductId == product.ProductId);
           //found.ProductImage = product.ProductImage;
            found.ProductName = product.ProductName;
            //found.ProductPrice = product.ProductPrice;
            found.Quantity = product.Quantity;
            context.SaveChanges();
        }
    }

}
