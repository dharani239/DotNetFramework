export interface Employee {
    EmpId:number;
    EmpName:string;
    EmpAddress:string;
    EmpSalary:number;
    DeptId:number;
}
